jQuery(document).ready(function($) {


    $(function() {
        $('#billing_city_field, #billing_state_field').wrapAll('<div class="modulo-regiones-titan"></div>');

    });

});